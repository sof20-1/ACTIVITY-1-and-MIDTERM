// Inventory Management System with Data Entry and Normalization in JavaScript

const mysql = require('mysql2');
const readline = require('readline');

// Database configuration
const dbConfig = {
    host: '127.0.0.1',
    user: 'root',
    password: 'Jihyee-1',
    database: 'inventory'
};

// Create a connection to the database
const connection = mysql.createConnection(dbConfig);
connection.connect(err => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to database.');
});

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function insertRawData() {
    rl.question("Enter Product Name: ", productName => {
        rl.question("Enter Quantity: ", quantity => {
            rl.question("Enter Supplier Name: ", supplierName => {
                rl.question("Enter Supplier Contact: ", supplierContact => {
                    rl.question("Enter Category Name: ", categoryName => {
                        // Insert Supplier if not exists
                        const supplierQuery = "INSERT IGNORE INTO suppliers (supplierName, contactInfo) VALUES (?, ?)";
                        connection.query(supplierQuery, [supplierName, supplierContact], (err, supplierResult) => {
                            if (err) {
                                console.error("Error inserting supplier:", err);
                                return promptUser();
                            }
                            
                            // Get Supplier ID
                            connection.query("SELECT supplierID FROM suppliers WHERE supplierName = ?", [supplierName], (err, supplierRows) => {
                                if (err || supplierRows.length === 0) {
                                    console.error("Error fetching supplier:", err);
                                    return promptUser();
                                }
                                const supplierID = supplierRows[0].supplierID;

                                // Insert Category if not exists
                                const categoryQuery = "INSERT IGNORE INTO categories (categoryName) VALUES (?)";
                                connection.query(categoryQuery, [categoryName], (err, categoryResult) => {
                                    if (err) {
                                        console.error("Error inserting category:", err);
                                        return promptUser();
                                    }

                                    // Get Category ID
                                    connection.query("SELECT categoryID FROM categories WHERE categoryName = ?", [categoryName], (err, categoryRows) => {
                                        if (err || categoryRows.length === 0) {
                                            console.error("Error fetching category:", err);
                                            return promptUser();
                                        }
                                        const categoryID = categoryRows[0].categoryID;

                                        // Insert Product
                                        const productQuery = "INSERT INTO products (productName, quantity, supplierID, categoryID) VALUES (?, ?, ?, ?)";
                                        connection.query(productQuery, [productName, quantity, supplierID, categoryID], err => {
                                            if (err) {
                                                console.error("Error inserting product:", err);
                                            } else {
                                                console.log("Product added successfully!");
                                            }
                                            promptUser();
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });
}

function showProducts() {
    connection.query("SELECT * FROM products", (err, results) => {
        if (err) {
            console.error("Error fetching products:", err);
            return;
        }
        console.table(results);
        promptUser();
    });
}

function showSuppliers() {
    connection.query("SELECT * FROM suppliers", (err, results) => {
        if (err) {
            console.error("Error fetching suppliers:", err);
            return;
        }
        console.table(results);
        promptUser();
    });
}

function showCategories() {
    connection.query("SELECT * FROM categories", (err, results) => {
        if (err) {
            console.error("Error fetching categories:", err);
            return;
        }
        console.table(results);
        promptUser();
    });
}

function showMenu() {
    console.log("\nInventory Management System:");
    console.log("1. Enter Raw Data");
    console.log("2. 1NF - Show Products Table");
    console.log("3. 2NF - Show Suppliers Table");
    console.log("4. 3NF - Show Categories Table");
    console.log("5. Exit");
}

function handleChoice(choice) {
    switch (choice) {
        case "1":
            insertRawData();
            break;
        case "2":
            showProducts();
            break;
        case "3":
            showSuppliers();
            break;
        case "4":
            showCategories();
            break;
        case "5":
            console.log("Exiting...");
            connection.end();
            rl.close();
            return;
        default:
            console.log("Invalid choice. Please enter a valid option.");
            promptUser();
    }
}

function promptUser() {
    showMenu();
    rl.question("Select an option: ", handleChoice);
}

promptUser();
